module1_core imported from provided build zip
