module3_kingdom imported from provided build zip
