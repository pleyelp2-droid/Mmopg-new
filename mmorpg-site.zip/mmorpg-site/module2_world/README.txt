module2_world imported from provided build zip
